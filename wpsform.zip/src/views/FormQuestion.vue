<template>
  <div>这是表单问题组件</div>
</template>

<script>
import { defineComponent } from "vue";
export default defineComponent({
  name: "FormQuestion",
  components: {},
  props: {},
  setup(props, ctx) {
    return {};
  },
});
</script>

<style scoped>
</style>