<template>
  <div>这是表单填写组件</div>
</template>

<script>
import { defineComponent } from "vue";
export default defineComponent({
  name: "FormWrite",
  components: {},
  props: {},
  setup(props, ctx) {
    return {};
  },
});
</script>

<style scoped>
</style>