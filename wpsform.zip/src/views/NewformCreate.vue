<template>
  <div>这是新建表单组件</div>
</template>

<script>
import { defineComponent } from "vue";
export default defineComponent({
  name: "NewformCreate.vue",
  components: {},
  props: {},
  setup(props, ctx) {
    return {};
  },
});
</script>

<style scoped>
</style>