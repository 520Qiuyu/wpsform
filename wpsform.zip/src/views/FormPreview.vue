<template>
  <div>
    这是表单预览组件
  </div>
</template>

<script>
import { defineComponent } from 'vue'
export default defineComponent ({
  name:'FormPreview',
  components:{},
  props:{},
  setup(props, ctx){
    return {
    }
  },
})
</script>

<style scoped>
div{
    margin-top: 100px;
}
</style>