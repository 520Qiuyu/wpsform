<template>
  <div>这是注册组件</div>
</template>

<script>
import { defineComponent } from "vue";
export default defineComponent({
  name: "RegisterView",
  components: {},
  props: {},
  setup(props, ctx) {
    return {};
  },
});
</script>

<style scoped>
</style>