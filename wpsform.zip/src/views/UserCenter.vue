<template>
  <div>这是用户中心组件</div>
</template>

<script>
import { defineComponent } from "vue";
export default defineComponent({
  name: "UserCenter",
  components: {},
  props: {},
  setup(props, ctx) {
    return {};
  },
});
</script>

<style scoped>
</style>