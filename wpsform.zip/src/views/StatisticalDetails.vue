<template>
  <div>这是统计详情组件</div>
</template>

<script>
import { defineComponent } from "vue";
export default defineComponent({
  name: "StatisticalDetails",
  components: {},
  props: {},
  setup(props, ctx) {
    return {};
  },
});
</script>

<style scoped>
</style>