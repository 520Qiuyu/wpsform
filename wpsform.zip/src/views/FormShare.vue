<template>
  <div>这是表单分享组件</div>
</template>

<script>
import { defineComponent } from "vue";
export default defineComponent({
  name: "FormShare",
  components: {},
  props: {},
  setup(props, ctx) {
    return {};
  },
});
</script>

<style scoped>
</style>