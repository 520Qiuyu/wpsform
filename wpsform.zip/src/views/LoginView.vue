<template>
  <div>这是登录组件</div>
</template>

<script>
import { defineComponent } from "vue";
export default defineComponent({
  name: "LoginView",
  components: {},
  props: {},
  setup(props, ctx) {
    return {};
  },
});
</script>

<style scoped>
</style>