<template>
  <div>
    这是分数问题
  </div>
</template>

<script>
import { defineComponent } from 'vue'
export default defineComponent ({
  name:'ScoreQuestion',
  components:{},
  props:{},
  setup(props, ctx){
    return {
    }
  },
})
</script>

<style scoped>
</style>