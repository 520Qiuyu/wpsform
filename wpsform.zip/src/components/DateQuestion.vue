<template>
  <div>
    这是日期问题
  </div>
</template>

<script>
import { defineComponent } from 'vue'
export default defineComponent ({
  name:'DateQuestion',
  components:{},
  props:{},
  setup(props, ctx){
    return {
    }
  },
})
</script>

<style scoped>
</style>