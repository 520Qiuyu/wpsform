<template>
  <div>
    这是下拉问题
  </div>
</template>

<script>
import { defineComponent } from 'vue'
export default defineComponent ({
  name:'PullSelect',
  components:{},
  props:{},
  setup(props, ctx){
    return {
    }
  },
})
</script>

<style scoped>
</style>