<template>
  <div>这是时间问题</div>
</template>

<script>
import { defineComponent } from "vue";
export default defineComponent({
  name: "TimeQuestion",
  components: {},
  props: {},
  setup(props, ctx) {
    return {};
  },
});
</script>

<style scoped>
</style>