import { Problem } from "@/types/types";
export default {
  namespaced: true,
  actions: {},
  mutations: {},
  state: {},
  getters: {},
};
