export default {
  namespaced: true,
  actions: {},
  mutations: {},
  state: {},
  getters: {},
};
