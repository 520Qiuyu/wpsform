<template>
  <router-view />
</template>

<script>
import "./assets/styles/reset.css";
import "./assets/styles/index.css";

export default {
  name: "App",
};
</script>

<style>
</style>
